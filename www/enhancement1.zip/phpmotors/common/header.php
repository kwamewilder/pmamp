
<img src="/phpmotors/images/site/logo.png" alt="logo for my site">   
